const express =require("express");

require('../src/db/conn')
const router=require('../src/routers/men')
const MensRanking=require('../src/models/mens');
const app=express();

app.use(express.json());
app.use(express.urlencoded({extended: false}));

const port=process.env.PORT || 8000;
app.use(router);

app.get("/",async(req,res)=>{
    res.send("Hello from the thapa");
})

app.listen(port,()=>{
    console.log(`connnecstion is  live  tofaya thapa ${port}`);
})