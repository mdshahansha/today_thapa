const mongoose=require('mongoose');
mongoose.Promise = global.Promise;

mongoose.connect("mongodb+srv://thapa:ggaappuu@cluster0.tkoqh.mongodb.net/user2?retryWrites=true&w=majority",{
    useNewUrlParser: true
}).then(()=>{
    console.log("connection succesful");
}).catch((e)=>{
    console.log("No Connection ",e)
}) 